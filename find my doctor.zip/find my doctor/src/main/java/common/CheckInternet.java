package common;


public class CheckInternet {
}
