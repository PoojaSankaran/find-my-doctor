package common;

import android.content.Context;
import android.content.SharedPreferences;

import java.util.regex.Pattern;


public class Configg {


    public static void storeDATA(Context context, String key, String value) {
        SharedPreferences preferences = context.getSharedPreferences("AUTHENTICATION_FILE_NAME", Context.MODE_WORLD_WRITEABLE);
        SharedPreferences.Editor editor = preferences.edit();
        editor.putString(key, value);
        editor.apply();
    }

    public static String getDATA(Context context, String key) {
        SharedPreferences prfs = context.getSharedPreferences("AUTHENTICATION_FILE_NAME", Context.MODE_PRIVATE);
        return prfs.getString(key, "");

    }
    public static final String MAIN_URL = "http://vajralabs.com/Taxi/";
    public static final String SIGNUP_ROOT = "signup_POST.php";
    public static final String SIGNUP_PATIENT_ROOT = "signup_patient_POST.php";

    public static final String SIGNUP_CONFIRMATION_ROOT = "signup_confirmation.php";
    public static final String DOCTOR_LIST = "doctor_list.php";
    public static final String GET_APPOINTMENT = "get_appointment.php";
    public static final String POST_STATUS = "post_status.php";


    public static final String USER_LOGIN = "user_login.php";
    public static final String USER_LOGIN_DOCTOR = "user_login_doctor.php";





    // Directory name to store captured images and videos
    public static final String IMAGE_DIRECTORY_NAME = "Android File Upload";
    public static final String EMAIL = "@gmail.com";
    public static final String PASSWORD = "";
    public static final String EDIT_DOCTOR ="doctor_edit.php";
    public static final String EDIT_PATIENT = "patient_edit.php";
    public static String url_path = "http://kpfba.info/";

    public static boolean isValidEmaillId(String email) {

        return Pattern.compile("^(([\\w-]+\\.)+[\\w-]+|([a-zA-Z]{1}|[\\w-]{2,}))@"
                + "((([0-1]?[0-9]{1,2}|25[0-5]|2[0-4][0-9])\\.([0-1]?"
                + "[0-9]{1,2}|25[0-5]|2[0-4][0-9])\\."
                + "([0-1]?[0-9]{1,2}|25[0-5]|2[0-4][0-9])\\.([0-1]?"
                + "[0-9]{1,2}|25[0-5]|2[0-4][0-9])){1}|"
                + "([a-zA-Z]+[\\w-]+\\.)+[a-zA-Z]{2,4})$").matcher(email).matches();
    }

}
