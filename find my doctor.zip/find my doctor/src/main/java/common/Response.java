package common;


public interface Response {
    void processFinish(String output);
}
